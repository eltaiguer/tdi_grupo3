﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WiimoteLib.Extensions
{
	public class NunchukExtension : IExtensionController<T>
	{
	}

	public class 
}
